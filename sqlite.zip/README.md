# cs251-sqlite
https://www.sitepoint.com/getting-started-sqlite3-basic-commands/
http://stackoverflow.com/questions/1786533/find-rows-that-have-the-same-value-on-a-column-in-mysql
https://en.wikipedia.org/wiki/Foreign_key
https://msdn.microsoft.com/en-us/library/ms179610.aspx
http://www.mysqltutorial.org/mysql-foreign-key/
https://sqlite.org/faq.html
https://www.ibm.com/developerworks/data/library/techarticle/dm-1301foreignkey/
